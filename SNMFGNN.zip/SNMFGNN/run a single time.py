import pandas as pd
import numpy as np
import tqdm
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import torch
from torch import Tensor
import torch.nn.functional as F
from torch_geometric.data import HeteroData
import torch_geometric.transforms as T
from torch_geometric.loader import LinkNeighborLoader
from torch_geometric.nn import SAGEConv, GATConv,GATv2Conv,GCNConv, to_hetero,GMMConv,SSGConv,ResGatedGraphConv,ARMAConv,MFConv
from sklearn.metrics import roc_auc_score,classification_report,precision_recall_curve,average_precision_score
from sklearn.metrics import roc_curve,accuracy_score,recall_score,precision_score,f1_score,log_loss
from utils import KfoldLinkSplit
from torch_geometric.data import HeteroData
#可重复性，固定seed
from torch_geometric import seed_everything

seed_everything(2023)
torch.manual_seed(2023)
np.random.seed(2023)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)



lambda_n_list = [0, 0.4, 0.8, 1.2, 1.6, 2.0]
lambda_oc_list = [0.0001, 0.001, 0.01, 0.1, 1, 10]
lambda_lc_list = [0.0001, 0.001, 0.01, 0.1, 1, 10]


# 生成文件路径
file_path1 = f'data1/C_0.8_0.001_1.npy'
file_path2 = f'data1/D_0.8_0.001_1.npy'

file_path3 = 'data1/associationMatrix.npy'


df_rna = np.load(file_path1)
df_diease = np.load(file_path2)
df_associations = np.load(file_path3)

print("df_rna shape:", df_rna.shape)
print("df_diease shape:", df_diease.shape)
print("df_associations shape:", df_associations.shape)

def standarize(arr):
    arr_max = arr.max()
    arr_min = arr.min()
    return (arr - arr_min) / (arr_max - arr_min)

# 创建 HeteroData 对象
data = HeteroData()
# 添加节点
data["diease"].node_id = torch.arange(len(df_diease))
data["rna"].node_id = torch.arange(len(df_rna))
# 添加节点数据
data["diease"].x = torch.Tensor(standarize(df_diease))
data["rna"].x = torch.Tensor(standarize(df_rna))
# 添加边
data['edge_index'] = torch.tensor(df_associations.nonzero(), dtype=torch.long)
associations_indices = np.where(df_associations == 1)
associations_indices = np.array(associations_indices)
data["rna", "association", "diease"].edge_index = torch.tensor(associations_indices, dtype=torch.long)

data = T.ToUndirected()(data)

print(data)

num_of_links = data["rna", "association", "diease"].edge_index.shape[1]
perm = torch.randperm(num_of_links).tolist()
# 确定折数
num_of_fold = 5
fold_size = int(num_of_links / num_of_fold)
train_list = []
val_list = []

for i in range(num_of_fold):
    transform = KfoldLinkSplit(
        num_val=0.2,  # 训练集20%
        num_test=0.0,
        disjoint_train_ratio=0.3,
        neg_sampling_ratio=1.0,  # 采样负样本边
        add_negative_train_samples=False,
        edge_types=("rna", "association", "diease"),
        rev_edge_types=("diease", "rev_association", "rna"),
        perm=perm  # 固定每一次随机的顺序
    )
    train_data, val_data, _ = transform(data)
    train_list.append(train_data)
    val_list.append(val_data)
    # fold向右滑动一步，依次轮换后20%
    perm_tmp = perm.copy()
    perm = perm_tmp[(num_of_fold - 1) * fold_size:] + perm_tmp[:(num_of_fold - 1) * fold_size]

class GNN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        # self.conv1 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        #self.conv2 = GATv2Conv(hidden_channels, hidden_channels,head=8,add_self_loops=False)
        #self.conv3 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        self.conv1 = SAGEConv(hidden_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, hidden_channels)
        # self.conv3 = SAGEConv(hidden_channels, hidden_channels)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        # x = self.conv3(x, edge_index)
        return x

class Classifier(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.att = torch.nn.MultiheadAttention(hidden_channels, 1, batch_first=True)
        self.fc1 = torch.nn.Linear(hidden_channels * 2, 1024)
        #self.fc2 = torch.nn.Linear(1024, 1024)
        self.fc2 = torch.nn.Linear(1024, 1)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, x_rna: Tensor, x_diease: Tensor, edge_label_index: Tensor, x_rna_skip: Tensor,
                x_diease_skip: Tensor) -> Tensor:
        # 读取4组特征，带skip的是不经过GNN处理的。
        edge_feat_rna = x_rna[edge_label_index[0]]
        edge_feat_diease = x_diease[edge_label_index[1]]
        edge_feat_rna_skip = x_rna_skip[edge_label_index[0]]
        edge_feat_diease_skip = x_diease_skip[edge_label_index[1]]
        # 拼接到一起
        feat_cat = torch.cat((edge_feat_rna, edge_feat_diease, edge_feat_rna_skip, edge_feat_diease_skip), dim=1)
        # self attention
        feat_cat_att, _ = self.att(feat_cat, feat_cat, feat_cat)
        # 将处理前后的特征拼接到一起
        feat_cat = torch.cat((feat_cat, feat_cat_att), dim=1)
        # 全连接
        feat_cat = F.relu(self.fc1(feat_cat))
        #feat_cat = self.dropout(feat_cat)
        feat_cat = self.fc2(feat_cat)
        #feat_cat = F.sigmoid(feat_cat)
        return feat_cat.squeeze()

class Model(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        # 使用embedding和linear函数构成输入层
        self.rna_lin = torch.nn.Linear(180, hidden_channels)
        self.diease_lin = torch.nn.Linear(180, hidden_channels)
        # 实例化GNN
        self.gnn = GNN(hidden_channels)
        # GNN异质图
        self.gnn = to_hetero(self.gnn, metadata=data.metadata())
        # 分类器
        self.classifier = Classifier(hidden_channels * 2 * 2)

    def forward(self, data: HeteroData) -> Tensor:
        x_dict = {
            "rna": self.rna_lin(data["rna"].x),
            "diease": self.diease_lin(data["diease"].x) ,
        }

        # `x_dict` 所有节点的特征矩阵
        # `edge_index_dict` 所有边的index
        x_dict_new = self.gnn(x_dict, data.edge_index_dict)
        x_dict_new["rna"] = x_dict_new["rna"] + x_dict_new["rna"] + x_dict_new["rna"]
        x_dict_new["diease"] = x_dict_new["diease"] + x_dict_new["diease"] + x_dict_new["diease"]
        pred = self.classifier(
            x_dict_new["rna"],
            x_dict_new["diease"],
            data["rna", "association", "diease"].edge_label_index,
            x_dict["rna"],
            x_dict["diease"],
        )
        return pred

def eval_loop(val_loader, fold=0, device='cpu'):
    model = Model(hidden_channels=256).to(device)
    model.load_state_dict(torch.load(f'./model1/best_model_{fold}.pth'))
    model.eval()
    preds = []
    ground_truths = []
    for sampled_data in val_loader:
        with torch.no_grad():
            sampled_data.to(device)
            preds.append(model(sampled_data))
            ground_truths.append(sampled_data["rna", "association", "diease"].edge_label)
    pred = torch.cat(preds, dim=0)
    pred = F.sigmoid(pred).cpu().numpy()
    ground_truth = torch.cat(ground_truths, dim=0).cpu().numpy()
    pred_return = pred.copy()
    ground_truth_return = ground_truth.copy()
    auc = roc_auc_score(ground_truth, pred)
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    pred = (pred >= 0.4).astype(np.int64)
    print(f"Validation AUC of fold {fold}: {auc:.4f}")
    print(classification_report(ground_truth, pred,zero_division=0.0))
    return pred_return,ground_truth_return,auc

def train_eval_loop(train_loader, val_loader, epochs, fold, device='cpu'):
    # 模型参数
    model = Model(hidden_channels=256).to(device)
    # optimizer = torch.optim.SGD(model.parameters(), lr=1e-3)
    #optimizer = torch.optim.Adam(model.parameters(), lr=1.5e-3)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    #scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.4)
    loss_list = []
    best_auc = 0.0
    best_epoch = 0
    best_val_loss = np.inf
    # 训练验证循环
    for epoch in range(1, epochs + 1):
        # 训练
        model.train()
        total_loss = total_examples = 0
        preds = []
        ground_truths = []
        for sampled_data in train_loader:
            optimizer.zero_grad()
            sampled_data.to(device)
            pred = model(sampled_data)
            ground_truth = sampled_data["rna", "association", "diease"].edge_label
            preds.append(pred)
            ground_truths.append(ground_truth)
            loss = F.binary_cross_entropy_with_logits(pred, ground_truth)
            loss.backward()
            optimizer.step()
            total_loss += float(loss) * pred.numel()
            total_examples += pred.numel()
        loss = total_loss / total_examples
        print(f"Epoch: {epoch:03d}, Train Loss: {loss:.4f} | ")
        loss_list.append(loss)
        pred = torch.cat(preds, dim=0)
        ground_truth = torch.cat(ground_truths, dim=0)
        pred = F.sigmoid(pred).detach().cpu().numpy()
        auc = roc_auc_score(ground_truth, pred)
        pred = (pred >= 0.4).astype(np.int64)
        acc = accuracy_score(ground_truth,pred)
        recall = recall_score(ground_truth,pred,zero_division=0.0)
        pre = precision_score(ground_truth, pred,zero_division=0.0)
        f1 = f1_score(ground_truth, pred,zero_division=0.0)
        print(f"Epoch: {epoch:03d} | Train loss: {loss:.4f}| Train acc: {acc:.4f}| Train AUC: {auc:.4f}| Train Precesion: {pre:.4f}| Train recall: {recall:.4f}| Train f1: {f1:.4f}")
        #scheduler.step()

        # 验证
        model.eval()
        preds = []
        ground_truths = []
        for sampled_data in val_loader:
            with torch.no_grad():
                sampled_data.to(device)
                preds.append(model(sampled_data))
                ground_truths.append(sampled_data["rna", "association", "diease"].edge_label)
        pred = torch.cat(preds, dim=0)
        ground_truth = torch.cat(ground_truths, dim=0)
        loss = F.binary_cross_entropy_with_logits(pred, ground_truth)
        pred = F.sigmoid(pred).cpu().numpy()
        auc = roc_auc_score(ground_truth, pred)
        pred = (pred >= 0.4).astype(np.int64)
        acc = accuracy_score(ground_truth,pred)
        recall = recall_score(ground_truth,pred,zero_division=0.0)
        pre = precision_score(ground_truth, pred,zero_division=0.0)
        f1 = f1_score(ground_truth, pred,zero_division=0.0)
        print(f"Epoch: {epoch:03d} | Val loss: {loss:.4f}| Val acc: {acc:.4f}| Val AUC: {auc:.4f}| Val Precesion: {pre:.4f}| Val recall: {recall:.4f}| Val f1: {f1:.4f}")
        if best_auc < auc:
            best_auc = auc
            best_epoch = epoch
            torch.save(model.state_dict(), f'./model1/best_model_{fold}.pth')
        print(f"best epoch :{best_epoch:03d} | Best auc :{best_auc:.4f} ")

    plt.plot(loss_list, label=f'Fold {fold}')
    plt.legend()
    plt.xlabel('Epoches')
    plt.ylabel('Loss')
    plt.savefig(f"./loss/loss_fold_{fold}.jpg")

for i in range(5):
    edge_label_index = train_list[i]["rna", "association", "diease"].edge_label_index
    edge_label = train_list[i]["rna", "association", "diease"].edge_label
    train_loader = LinkNeighborLoader(
        data=train_list[i],
        num_neighbors=[20, 10],
        neg_sampling_ratio=1.0,
        edge_label_index=(("rna", "association", "diease"), edge_label_index),
        edge_label=edge_label,
        batch_size=32,
        shuffle=True,
    )

    edge_label_index_val = val_list[i]["rna", "association", "diease"].edge_label_index
    edge_label_val = val_list[i]["rna", "association", "diease"].edge_label
    val_loader = LinkNeighborLoader(
        data=val_list[i],
        num_neighbors=[20, 10],
        edge_label_index=(["rna", "association", "diease"], edge_label_index_val),
        edge_label=edge_label_val,
        batch_size=128,
        shuffle=False,
    )
    train_eval_loop(train_loader, val_loader, epochs=200, fold=i, device=device)
plt.close()
# 预测
pred_lists =[]
gt_lists = []
auc_sum = 0.0
for i in range(5):
    edge_label_index = val_list[i]["rna", "association", "diease"].edge_label_index
    edge_label = val_list[i]["rna", "association", "diease"].edge_label
    val_loader = LinkNeighborLoader(
        data=val_list[i],
        num_neighbors=[20, 10],
        edge_label_index=(["rna", "association", "diease"], edge_label_index),
        edge_label=edge_label,
        batch_size=128,
        shuffle=False,
    )

    #auc_list.append(eval_loop(val_loader, fold=i, device=device))
    p,g,a = eval_loop(val_loader, fold=i, device=device)
    auc_sum += a
    pred_lists.append(p)
    gt_lists.append(g)

plt.close()
auc_sum = 0
fpr_list = []
tpr_list = []
preci=0.0
reca=0.0
accu=0.0
f1s=0.0
lss=0.0
#lss=0.0

for fold,(ground_truth, pred) in enumerate(zip(gt_lists,pred_lists)):
    auc = roc_auc_score(ground_truth, pred)
    preci += precision_score(ground_truth, (pred >= 0.4).astype(np.int64))
    reca += recall_score(ground_truth, (pred >= 0.4).astype(np.int64))
    f1s += f1_score(ground_truth, (pred >= 0.4).astype(np.int64))
    accu += accuracy_score(ground_truth, (pred >= 0.4).astype(np.int64))
    lss += log_loss(ground_truth,pred)
    auc_sum += auc
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    fpr_list.append(fpr)
    tpr_list.append(tpr)
    plt.plot(fpr, tpr, label=f'fold {fold} AUC: {auc:.4f}')
with open('output.txt', 'a',encoding='utf-8') as file:
    # file.write('当lambda_n={},lambda_oc={},lambda_lc={}时,指标如下\n'.format(lambda_n,lambda_oc,lambda_lc))
    file.write(f'Average Precision: {preci / 5:.4f}\n')
    file.write(f'Average Recall: {reca / 5:.4f}\n')
    file.write(f'Average F1: {f1s / 5:.4f}\n')
    file.write(f'Average Accuracy: {accu / 5:.4f}\n')
    file.write(f'Average loss: {lss / 5:.4f}\n')
def interpolate(x_list,y_list):
    y_l = []
    for i,(x,y) in enumerate(zip(x_list,y_list)):
        y_l.append(np.interp(np.linspace(0,1,101),x,y))
    return np.average(np.array(y_l),axis=0)

plt.plot(np.linspace(0,1,101),interpolate(fpr_list,tpr_list),'r--',label=f'Average AUC: {auc_sum/5:.4f}')
# plt.plot(np.linspace(0,1,101),interpolate(fpr_list,tpr_list),'r--',label=f'Average AUC: {auc_sum/5:.4f}')

plt.plot([0,1],[0,1],'k--')
plt.legend()
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.savefig(f'./roc/ROCcurve.jpg')

plt.close()
auprc_sum = 0
precision_list = []
recall_list = []
for fold,(ground_truth, pred) in enumerate(zip(gt_lists,pred_lists)):
    auprc = average_precision_score(ground_truth, pred)
    auprc_sum += auprc
    precision, recall, thresholds = precision_recall_curve(ground_truth, pred)
    precision = np.insert(precision,0,0.0)
    recall = np.insert(recall,0,1.0)
    precision_list.append(precision)
    recall_list.append(recall)
    precision_disp = precision.copy()
    #for i in range(1):
     #  precision_disp[-i] = 1.0
    plt.plot(precision_disp, recall, label=f'fold {fold} PR: {auprc:.4f}')

plt.plot(np.linspace(0,1,101),interpolate(precision_list,recall_list),'r--',label=f'Average PR: {auprc_sum/5:.4f}')
plt.plot([0,1],[1,0],'k--')
plt.legend()
plt.xlabel('Precision')
plt.ylabel('Recall')
plt.savefig(f'./roc/PRC.jpg')

with open('output.txt', 'a',encoding='utf-8') as file:
    file.write(f'Average AUC of 5 folds is: {auc_sum / 5}\n')
    file.write("\n")