import numpy as np


class MatrixFactorization:
    def __init__(self):
        pass

    def svd_init(self, A, k):
        U, S, V = np.linalg.svd(A)
        C = np.dot(U[:, :k], np.sqrt(np.diag(S[:k])))
        D = np.dot(V.T[:, :k], np.sqrt(np.diag(S[:k])))
        return C, D

    def random_init(self, m, n, k):
        # 随机生成非负的C和D矩阵作为初始值
        C = np.random.uniform(low=0.05, high=0.06, size=(m, k))
        D = np.random.uniform(low=0.05, high=0.06, size=(n, k))
        # C = np.random.uniform(low=0, high=1, size=(m, k))
        # D = np.random.uniform(low=0, high=1, size=(n, k))
        return C, D

    # 计算S的拉普拉斯矩阵L
    def laplacian(self, S):
        D = np.diag(np.sum(S, axis=1))
        L = D - S
        return L, D

    def loss_func(self, Y, C, D, N, GC, GD, lambda_n, lambda_oc, lambda_od, lambda_lc, lambda_ld):
        loss = np.linalg.norm(Y - np.dot(C, D.T) - N, 'fro') ** 2 + lambda_n * np.sum(
            np.abs(N)) + lambda_oc * np.linalg.norm(C, 'fro') ** 2 + lambda_od * np.linalg.norm(D,
                                                                                                'fro') ** 2 + lambda_lc * np.trace(
            np.dot(np.dot(C.T, GC), C)) + lambda_ld * np.trace(np.dot(np.dot(D.T, GD), D))
        return loss

    def update_matrix_E(self, Y, C, D, lambda_n):
        m, n = Y.shape
        N = np.zeros_like(Y)
        X = Y - np.dot(C, D.T)
        for i in range(m):
            for j in range(n):
                if X[i, j] > lambda_n / 2:
                    N[i, j] = X[i, j] - lambda_n / 2
                elif X[i, j] < lambda_n / 2:
                    N[i, j] = X[i, j] + lambda_n / 2
                else:
                    N[i, j] = 0

        return N

    def NMF_sparse_entries(self, Y, SC, SD, lambda_n, lambda_oc, lambda_od, lambda_lc, lambda_ld, r,
                           max_iter_main, max_iter_sub, diff_threshold, tol):
        m, n = Y.shape
        C, D = self.random_init(m, n, r)
        # C, D = self.svd_init(Y, r)
        # C = np.random.rand(m, r)
        # D = np.random.rand(n, r)
        # print('C,D矩阵的形状:', C.shape, D.shape)

        GC, IC = self.laplacian(SC)
        GD, ID = self.laplacian(SD)

        loss_list = []
        iter = 0
        stop_outer_loop = False
        while iter < max_iter_main and not stop_outer_loop:
            N = self.update_matrix_E(Y, C, D, lambda_n)
            iter_sub = 0
            while iter_sub < max_iter_sub and not stop_outer_loop:
                loss = self.loss_func(Y, C, D, N, GC, GD, lambda_n, lambda_oc, lambda_od, lambda_lc, lambda_ld)
                if iter % 10 == 0 and (iter_sub == 0 or iter_sub == max_iter_sub - 1):
                    print("Iteration: {} Loss: {}".format(iter, loss))
                    loss_list.append(loss)
                    if len(loss_list) >= 4:
                        diff = abs(loss_list[-4] - loss_list[-3]) + abs(loss_list[-3] - loss_list[-2]) + abs(
                            loss_list[-2] - loss_list[-1])
                        if diff < diff_threshold:
                            stop_outer_loop = True
                            break
                if tol > loss:
                    stop_outer_loop = True
                    break
                C_new = C * ((np.dot(Y - N, D) + lambda_lc * np.dot(SC, C)) / (
                        np.dot(np.dot(C, D.T), D) + lambda_oc * C + lambda_lc * np.dot(IC, C)))
                D_new = D * ((np.dot((Y - N).T, C) + lambda_ld * np.dot(SD, D)) / (
                        np.dot(np.dot(D, C.T), C) + lambda_od * D + lambda_ld * np.dot(ID, D)))

                C=C_new
                D=D_new

                iter_sub += 1
            iter += 1
        return C, D


class Re_Matix:
    def __init__(self):
        pass

    def find_k_largest_elements(self, matrix, i, k):
        # 输入为（相似性矩阵，第i个RNA/疾病，前k个最大）
        # 删除第i行的第i个元素
        row_without_i = np.delete(matrix[i, :], i)
        # 找到前k个最大元素的索引
        largest_indices = np.argsort(row_without_i)[-k:]
        # 计算对应的元素值
        largest_elements = row_without_i[largest_indices]
        # 将索引值转换为在原始矩阵中的索引
        largest_indices = largest_indices + (largest_indices >= i)
        return largest_elements, largest_indices

    def process_matrix(self, new_circrna_disease_matrix, circ_sim_matrix, dis_sim_matrix, k):
        if k != 0:
            # 重构邻接矩阵
            # 水平重构
            A_R = np.zeros_like(new_circrna_disease_matrix)
            for i in range(new_circrna_disease_matrix.shape[0]):
                values_r, indices_r = self.find_k_largest_elements(circ_sim_matrix, i, k)
                sum_R = 0
                sum_v_r = 0
                for j in range(k):
                    # 最大的元素与他们对应的行向量乘积的和
                    sum_R = sum_R + values_r[j] * new_circrna_disease_matrix[indices_r[j], :]
                for v in range(k):
                    sum_v_r += values_r[v]
                # if sum_v_r!=0:
                A_R[i, :] = sum_R / sum_v_r
                # else:
                #     A_R[i, :] =0
            # 垂直重构
            A_D = np.zeros_like(new_circrna_disease_matrix)
            for i in range(new_circrna_disease_matrix.shape[1]):
                values_d, indices_d = self.find_k_largest_elements(dis_sim_matrix, i, k)
                sum_D = 0
                sum_v_d = 0
                for j in range(k):
                    # 最大的元素与他们对应的列向量乘积的和
                    sum_D = sum_D + values_d[j] * new_circrna_disease_matrix[:, indices_d[j]]
                for v in range(k):
                    sum_v_d += values_d[v]

                # if sum_v_d!=0:
                A_D[:, i] = sum_D / sum_v_d
                # else:
                #     A_D[:, i] =0


            A_RD = (A_D + A_R) / 2

            re_circrna_disease_matrix = np.zeros_like(new_circrna_disease_matrix)
            for i in range(new_circrna_disease_matrix.shape[0]):
                for j in range(new_circrna_disease_matrix.shape[1]):
                    re_circrna_disease_matrix[i, j] = max(A_RD[i][j], new_circrna_disease_matrix[i][j])
        else:
            re_circrna_disease_matrix = new_circrna_disease_matrix

        return re_circrna_disease_matrix
