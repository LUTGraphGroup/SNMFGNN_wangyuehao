from model import MatrixFactorization, Re_Matix
import time
import numpy as np

# 导入超参
from hyperparams import *

start_time = time.time()

if __name__ == '__main__':
    circrna_disease_matrix = np.load('associationMatrix.npy')
    circ_sim_matrix = np.load('RS.npy')
    dis_sim_matrix = np.load('DS.npy')

    new_circrna_disease_matrix = circrna_disease_matrix.copy()

    print(new_circrna_disease_matrix.shape)

    re_m = Re_Matix()
    re_circrna_disease_matrix = re_m.process_matrix(new_circrna_disease_matrix, circ_sim_matrix, dis_sim_matrix, k)

    mf = MatrixFactorization()
    C, D = mf.NMF_sparse_entries(re_circrna_disease_matrix, circ_sim_matrix, dis_sim_matrix, lambda_n, lambda_oc,
                                 lambda_od, lambda_lc, lambda_ld, r,
                                 max_iter_main, max_iter_sub, diff_threshold, tol)

    np.save('C.npy',C)
    np.save('D.npy',D)
    print(C.shape,D.shape)