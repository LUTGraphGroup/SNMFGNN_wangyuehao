import pandas as pd
import numpy as np
import tqdm
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import torch
from torch import Tensor
import torch.nn.functional as F
from torch_geometric.data import HeteroData
import torch_geometric.transforms as T
from torch_geometric.loader import LinkNeighborLoader
from torch_geometric.nn import SAGEConv, GATConv,GATv2Conv,GCNConv, to_hetero,GMMConv,SSGConv,ResGatedGraphConv,ARMAConv,MFConv
from sklearn.metrics import roc_auc_score,classification_report,precision_recall_curve,average_precision_score
from sklearn.metrics import roc_curve,accuracy_score,recall_score,precision_score,f1_score,log_loss
from utils import KfoldLinkSplit
from torch_geometric.data import HeteroData
#可重复性，固定seed
from torch_geometric import seed_everything

seed_everything(99)
torch.manual_seed(99)
np.random.seed(99)

# 检查是否能使用gpu，如果能使用device=cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

file_path1 = 'data1/C_0.4_10_0.01.npy'
file_path2 = 'data1/D_0.4_10_0.01.npy'
file_path3 = 'data1/associationMatrix.npy'
file_path4 = 'data1/C.npy'
file_path5 = 'data1/D.npy'
df_rna1 = np.load(file_path1)
df_diease1 = np.load(file_path2)
df_associations = np.load(file_path3)
df_rna2 = np.load(file_path4)
df_diease2 = np.load(file_path5)
df_rna = df_rna1 + df_rna2
df_diease = df_diease1 + df_diease2
print("df_rna shape:", df_rna.shape)
print("df_diease shape:", df_diease.shape)
print("df_associations shape:", df_associations.shape)

def standarize(arr):
    arr_max = arr.max()
    arr_min = arr.min()
    return (arr - arr_min) / (arr_max - arr_min)

# 创建 HeteroData 对象
data = HeteroData()
# 添加节点
data["diease"].node_id = torch.arange(len(df_diease))
data["rna"].node_id = torch.arange(len(df_rna))
# 添加节点数据
data["diease"].x = torch.Tensor(standarize(df_diease))
data["rna"].x = torch.Tensor(standarize(df_rna))
# 添加边
data['edge_index'] = torch.tensor(df_associations.nonzero(), dtype=torch.long)
associations_indices = np.where(df_associations == 1)
associations_indices = np.array(associations_indices)
data["rna", "association", "diease"].edge_index = torch.tensor(associations_indices, dtype=torch.long)

data = T.ToUndirected()(data)
# 划分数据集,5折
# 随机打乱序号
print(data)
num_of_links = data["rna", "association", "diease"].edge_index.shape[1]
perm = torch.randperm(num_of_links).tolist()
# 确定折数
num_of_fold = 5
fold_size = int(num_of_links / num_of_fold)
train_list = []
val_list = []

for i in range(num_of_fold):
    transform = KfoldLinkSplit(
        num_val=0.2,  # 训练集20%
        num_test=0.0,
        disjoint_train_ratio=0.2,
        neg_sampling_ratio=5.0,  # 采样负样本边
        add_negative_train_samples=False,
        edge_types=("rna", "association", "diease"),
        rev_edge_types=("diease", "rev_association", "rna"),
        perm=perm  # 固定每一次随机的顺序
    )
    train_data, val_data, _ = transform(data)
    train_list.append(train_data)
    val_list.append(val_data)
    # fold向右滑动一步，依次轮换后20%
    perm_tmp = perm.copy()
    perm = perm_tmp[(num_of_fold - 1) * fold_size:] + perm_tmp[:(num_of_fold - 1) * fold_size]

#print(data)
# 网络模型
# 图注意力
class GNN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.conv1 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        self.conv2 = GATv2Conv(hidden_channels, hidden_channels,head=8,add_self_loops=False)
        # self.conv3 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        # self.conv1 = SAGEConv(hidden_channels, hidden_channels)
        # self.conv2 = SAGEConv(hidden_channels, hidden_channels)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        # x = self.conv3(x, edge_index)
        return x

class GCN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.conv1 = ResGatedGraphConv(hidden_channels, hidden_channels)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        return x

class GMM(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.conv1 = MFConv(hidden_channels, hidden_channels)
        self.conv2 = MFConv(hidden_channels, hidden_channels)
        self.conv3 = MFConv(hidden_channels, hidden_channels)


    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        x = self.conv3(x, edge_index)
        return x

class Classifier(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.att = torch.nn.MultiheadAttention(hidden_channels, 1, batch_first=True)
        self.fc1 = torch.nn.Linear(hidden_channels * 2, 1024)
        #self.fc2 = torch.nn.Linear(1024, 1024)
        self.fc2 = torch.nn.Linear(1024, 1)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, x_rna: Tensor, x_diease: Tensor, edge_label_index: Tensor, x_rna_skip: Tensor,
                x_diease_skip: Tensor) -> Tensor:
        # 读取4组特征，带skip的是不经过GNN处理的。
        edge_feat_rna = x_rna[edge_label_index[0]]
        edge_feat_diease = x_diease[edge_label_index[1]]
        edge_feat_rna_skip = x_rna_skip[edge_label_index[0]]
        edge_feat_diease_skip = x_diease_skip[edge_label_index[1]]
        # 拼接到一起
        feat_cat = torch.cat((edge_feat_rna, edge_feat_diease, edge_feat_rna_skip, edge_feat_diease_skip), dim=1)
        # self attention
        feat_cat_att, _ = self.att(feat_cat, feat_cat, feat_cat)
        # 将处理前后的特征拼接到一起
        feat_cat = torch.cat((feat_cat, feat_cat_att), dim=1)
        # 全连接
        feat_cat = F.relu(self.fc1(feat_cat))
        #feat_cat = self.dropout(feat_cat)
        feat_cat = self.fc2(feat_cat)
        #feat_cat = F.sigmoid(feat_cat)
        return feat_cat.squeeze()

class Model(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        # 使用embedding和linear函数构成输入层
        self.rna_lin = torch.nn.Linear(data["rna"].x.shape[1], hidden_channels)
        self.diease_lin = torch.nn.Linear(data["diease"].x.shape[1], hidden_channels)
        self.rna_emb = torch.nn.Embedding(data["rna"].num_nodes, hidden_channels)
        self.diease_emb = torch.nn.Embedding(data["diease"].num_nodes, hidden_channels)
        # 实例化GNN
        self.gnn = GNN(hidden_channels)
        self.gcn = GCN(hidden_channels)
        self.gmm = GMM(hidden_channels)
        # GNN异质图
        self.gnn = to_hetero(self.gnn, metadata=data.metadata())
        self.gcn = to_hetero(self.gcn, metadata=data.metadata())
        self.gmm = to_hetero(self.gmm, metadata=data.metadata())
        # 分类器
        self.classifier = Classifier(hidden_channels * 2 * 2)

    def forward(self, data: HeteroData) -> Tensor:
        x_dict = {
            "rna": self.rna_lin(data["rna"].x) + self.rna_emb(data["rna"].node_id),
            "diease": self.diease_lin(data["diease"].x) + self.diease_emb(data["diease"].node_id),
        }

        # `x_dict` 所有节点的特征矩阵
        # `edge_index_dict` 所有边的index
        x_dict_new = self.gnn(x_dict, data.edge_index_dict)
        x_dict_new2 = self.gcn(x_dict, data.edge_index_dict)
        x_dict_new3 = self.gmm(x_dict, data.edge_index_dict)
        x_dict_new["rna"] =x_dict_new["rna"] +0.1*x_dict_new2["rna"] +0.1*x_dict_new3["rna"] +x_dict_new["rna"] + x_dict_new2["rna"]
        x_dict_new["diease"] =x_dict_new["diease"] +0.1*x_dict_new2["diease"] +0.1*x_dict_new3["diease"] +x_dict_new["diease"]+x_dict_new2["diease"]
        pred = self.classifier(
            x_dict_new["rna"],
            x_dict_new["diease"],
            data["rna", "association", "diease"].edge_label_index,
            x_dict["rna"],
            x_dict["diease"],
        )
        return pred

# 验证
def eval_loop(val_loader, fold=0, device='cpu'):
    model = Model(hidden_channels=128).to(device)
    model.load_state_dict(torch.load(f'./model/best_model_{fold}.pth'))
    model.eval()
    preds = []
    ground_truths = []
    for sampled_data in val_loader:
        with torch.no_grad():
            sampled_data.to(device)
            preds.append(model(sampled_data))
            ground_truths.append(sampled_data["rna", "association", "diease"].edge_label)
    pred = torch.cat(preds, dim=0)
    pred = F.sigmoid(pred).cpu().numpy()
    ground_truth = torch.cat(ground_truths, dim=0).cpu().numpy()
    pred_return = pred.copy()
    ground_truth_return = ground_truth.copy()
    auc = roc_auc_score(ground_truth, pred)
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    pred = (pred >= 0.3).astype(np.int64)
    print(f"Validation AUC of fold {fold}: {auc:.4f}")
    print(classification_report(ground_truth, pred,zero_division=0.0))
    return pred_return,ground_truth_return,auc
# 预测

i=0
edge_label_index = val_list[i]["rna", "association", "diease"].edge_label_index
edge_label = val_list[i]["rna", "association", "diease"].edge_label
val_loader = LinkNeighborLoader(
    data=val_list[i],
    num_neighbors=[20, 10],
    edge_label_index=(["rna", "association", "diease"], edge_label_index),
    edge_label=edge_label,
    batch_size=128,
    shuffle=False,
)

# auc_list.append(eval_loop(val_loader, fold=i, device=device))
p, g, a = eval_loop(val_loader, fold=i, device=device)
edge_label_index = edge_label_index.detach().cpu().numpy()
rnaname = pd.read_excel('./data/circRNA.xlsx')['circRNA Name']
dieasename = pd.read_excel('./data/diseaseName1.xlsx')['disease Name']
save_list = []
for i in range(len(p)):
    didx = edge_label_index[1,i]
    ridx = edge_label_index[0,i]
    save_list.append([dieasename[didx],rnaname[ridx],p[i],g[i]])

pd.DataFrame(save_list,columns=['Diease','rna','pred scores','ground truth']).to_csv('case.csv')